# Author:  Dennis Sprous
# Created: 11-Feb-2020
# Purpose: Hello world it too boring.  
#          Piet Hein's Grooks comforts the soul
#           

from grooks.grooks import anyProblem

def main():
    anyProblem()

main()

