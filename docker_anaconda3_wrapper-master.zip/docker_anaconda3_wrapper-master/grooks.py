# Author:  Dennis Sprous
# Created: 11-Feb-2020
# Purpose: Hello world it too boring.  
#          Piet Hein's Grooks comforts the soul
#           

def anyProblem():
    print( '''
           Any problem        worthy of attack
           proves its worth   by fighting back
               Piet Heins
           ''' )


